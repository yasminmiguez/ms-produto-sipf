export type bibliotecaDTO = {
    id: number;
    nome: string;
    endereco: string;
}