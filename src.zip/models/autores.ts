export type AutorDTO = {
    id: number;
    nome: string;
}