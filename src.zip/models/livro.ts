import type { AutorDTO } from "./autores";
import type { bibliotecaDTO } from "./biblioteca";

export type LivroDTO = {
    id: number;
    titulo: string;
    genero: string;
    anoPublicacao: BigInteger;

    autor: AutorDTO;

    biblioteca: bibliotecaDTO;
    
}