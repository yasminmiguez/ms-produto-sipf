import axios from "axios";
import type { AutorDTO } from "../models/autores"; // Certifique-se deste caminho!

// BASE_URL provavelmente está em src/utils/system.ts
import { BASE_URL } from "../utils/system"; 

// Exportação nomeada da função findAll
export async function findAll(): Promise<AutorDTO[]>{
    // A requisição usa a URL base e o endpoint /autores
    const response = await axios.get(`${BASE_URL}/autores`);
    
    // IMPORTANTE: Se sua API retornar um objeto aninhado como { content: [...] }, 
    // você PRECISA mudar a linha abaixo para:
    // return response.data.content;
    
    return response.data
}