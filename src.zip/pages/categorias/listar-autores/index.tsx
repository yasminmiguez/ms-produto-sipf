/* eslint-disable @typescript-eslint/no-unused-vars */
import {
    Box,
    CircularProgress,
    Paper,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Typography,
    Alert,
    IconButton, // Adicionado para exibir erros de forma mais clara
} from "@mui/material";
import { useEffect, useState } from "react";

import axios from "axios";
// Importa o tipo DTO
import type { AutorDTO } from "../../../models/autores"; 
import { findAll } from "../../../service/autor-service";
import { Link } from "react-router-dom";
import { Delete, Edit } from "@mui/icons-material";

// Importa a função findAll diretamente (Export Nomeado)



export default function ListarAutores() {
    // Estados para dados, carregamento e erro
    const [autores, setAutores] = useState<AutorDTO[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const fetchAutores = async () => {
            try {
                // 1. Chamada CORRETA da função (findAll sem o prefixo autorService)
                const data = await findAll();
                setAutores(data);
            } catch (error: unknown) {
                // Tratamento de erro detalhado
                let msg = "Erro ao carregar Autores! Verifique o console do navegador.";
                if (axios.isAxiosError(error) && error.response) {
                    // Tenta obter a mensagem de erro da resposta da API
                    msg = error.response.data.error || msg; 
                }
                setError(msg);
            } finally {
                setLoading(false);
            }
        };
        fetchAutores();
    }, []);

    return (
        <Box sx={{ p: 4 }}>
            <Typography variant="h4" component="h1" gutterBottom>
                Listagem de Autores
            </Typography>

            {/* 1. Exibir Erro */}
            {error && (
                <Alert severity="error" sx={{ mb: 3 }}>
                    {error}
                </Alert>
            )}

            {/* 2. Exibir Carregamento */}
            {loading ? (
                <Box sx={{ display: "flex", justifyContent: "center", mt: 4 }}>
                    <CircularProgress />
                </Box>
            ) : (
                // 3. Exibir Tabela se não houver erro
                !error && (
                    <TableContainer component={Paper}>
                        <Table sx={{ minWidth: 650 }} aria-label="simple table">
                            <TableHead>
                                <TableRow>
                                    <TableCell>ID</TableCell>
                                    <TableCell>Nome</TableCell>
                                    <TableCell>Ações</TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {/* Itera e exibe a lista de autores */}
                                {autores.map((autor) => (
                                    <TableRow key={autor.id}>
                                        <TableCell>{autor.id}</TableCell>
                                        <TableCell>{autor.nome}</TableCell>

                                        <TableCell>
                                        <IconButton aria-label="editar" component={Link} to={`/autores/${autor.id}/editar`}>
                                        
                                        <Edit />
                                        </IconButton>
                                        <IconButton aria-label="excluir"
                                            onClick={() => console.log("Excluir autores: "+ autor.id)
                                            }
                                            sx={{ ml: 1}}>
                                                <Delete />
                                        </IconButton>
                                            {/* Adicione botões de Ações (Editar/Excluir) aqui */}
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                        {/* Mensagem se a lista estiver vazia */}
                        {autores.length === 0 && (
                            <Typography variant="body1" sx={{ p: 2, textAlign: 'center' }}>
                                Nenhum autor encontrado.
                            </Typography>
                        )}
                    </TableContainer>
                )
            )}
        </Box>
    );
}