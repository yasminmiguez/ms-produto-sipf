package br.com.fiap.ms_livros;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsLivrosApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsLivrosApplication.class, args);
	}

}
