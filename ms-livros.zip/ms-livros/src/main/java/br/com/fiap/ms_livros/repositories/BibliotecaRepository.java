package br.com.fiap.ms_livros.repositories;

import br.com.fiap.ms_livros.entities.Biblioteca;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BibliotecaRepository extends JpaRepository<Biblioteca, Long> {
}
