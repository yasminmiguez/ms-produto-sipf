package br.com.fiap.ms_livros.controller;

import br.com.fiap.ms_livros.dto.AutorDTO;
import br.com.fiap.ms_livros.dto.LivroDTO;
import br.com.fiap.ms_livros.service.AutorService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/autores")
@CrossOrigin(origins = "*")
public class AutorController {

    @Autowired
    private AutorService service;

    @GetMapping("/{id}/livros")
    public ResponseEntity<List<LivroDTO>> findLivrosByAutor(@PathVariable Long id){

        List<LivroDTO> list = service.findLivrosByAutor(id);
        return ResponseEntity.ok(list);
    }


    @GetMapping
    public ResponseEntity<List<AutorDTO>> findAll(){
        List<AutorDTO> dto = service.findAll();
        return ResponseEntity.ok(dto);
    }
    @GetMapping("/{id}")
    public ResponseEntity<AutorDTO> findById(@PathVariable Long id){
        AutorDTO dto = service.findById(id);
        return ResponseEntity.ok(dto);
    }

    @PostMapping
    public ResponseEntity<AutorDTO> createAutor(
            @RequestBody @Valid AutorDTO dto){
        dto = service.create(dto);
        URI uri = ServletUriComponentsBuilder
                .fromCurrentRequestUri()
                .path("/{id}")
                .buildAndExpand(dto.getId())
                .toUri();

        return ResponseEntity.created(uri).body(dto);
    }
    @PutMapping("/{id}")
    public ResponseEntity<AutorDTO> updateAutor(
            @PathVariable Long id,
            @RequestBody @Valid AutorDTO dto) {
        dto = service.update(id, dto);
        return ResponseEntity.ok(dto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteAutor(@PathVariable Long id){
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

}
