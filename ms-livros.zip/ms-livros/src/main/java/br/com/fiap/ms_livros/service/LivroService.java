package br.com.fiap.ms_livros.service;

import br.com.fiap.ms_livros.dto.BibliotecaDTO;
import br.com.fiap.ms_livros.dto.LivroDTO;
import br.com.fiap.ms_livros.entities.Autor;
import br.com.fiap.ms_livros.entities.Biblioteca;
import br.com.fiap.ms_livros.entities.Livro;
import br.com.fiap.ms_livros.repositories.BibliotecaRepository;
import br.com.fiap.ms_livros.repositories.LivroRepository;
import br.com.fiap.ms_livros.service.exceptions.DatabaseException;
import br.com.fiap.ms_livros.service.exceptions.ResourceNotFoundException;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service

public class LivroService {


    @Autowired
    private LivroRepository repository;

    @Autowired
    private br.com.fiap.ms_livros.repositories.AutorRepository autorRepository;

    @Autowired
    private BibliotecaRepository bibliotecaRepository;

    @Transactional(readOnly = true)
    public List<LivroDTO> findAll() {
        List<Livro> list = repository.findAll();
        return list.stream().map(LivroDTO::new).toList();
    }



    @Transactional(readOnly = true)
    public LivroDTO findById(Long id) {

        Livro entity = repository.findById(id).orElseThrow(
                () -> new ResourceNotFoundException("Recurso não encontrado. Id: " + id)
        );
        return new LivroDTO(entity);
    }

    @Transactional
    public LivroDTO insert(LivroDTO dto) {

        try {
            Livro entity = new Livro();
            // metodo auxiliar para converter DTO para Entity
            toEntity(dto, entity);
            entity = repository.save(entity);
            return new LivroDTO(entity);
        } catch (DataIntegrityViolationException ex) {
            throw new DatabaseException("Violação de integridade referencial - Autor ID: "
                    + dto.getAutor().getId());
        }
    }



    @Transactional
    public LivroDTO update(Long id, LivroDTO requestDTO) {

        try {
            Livro entity = repository.getReferenceById(id);
            toEntity(requestDTO, entity);
            entity = repository.save(entity);
            return new LivroDTO(entity);
        } catch (EntityNotFoundException ex) {
            throw new ResourceNotFoundException("Recurso não encontrado. Id: " + id);
        }
    }

    @Transactional
    public void delete(Long id) {

        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Recurso não encontrado. Id: " + id);
        }
        repository.deleteById(id);
    }

    private void toEntity(LivroDTO dto, Livro entity) {
        entity.setTitulo(dto.getTitulo());
        entity.setGenero(dto.getGenero());
        entity.setAnoPublicacao(dto.getAnoPublicacao());

        // Objeto completo gerenciado
        Autor autor = autorRepository.getReferenceById(dto.getAutor().getId());
        entity.setAutor(autor);

        entity.getBibliotecas().clear();
        for (BibliotecaDTO bibliotecaDTO : dto.getBibliotecas()) {
            Biblioteca biblioteca = bibliotecaRepository.getReferenceById(bibliotecaDTO.getId());
            entity.getBibliotecas().add(biblioteca);
        }
    }


}
