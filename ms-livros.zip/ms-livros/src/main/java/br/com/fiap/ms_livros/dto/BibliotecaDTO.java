package br.com.fiap.ms_livros.dto;

import br.com.fiap.ms_livros.entities.Biblioteca;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Getter
public class BibliotecaDTO {

    private Long id;

    @NotBlank(message = "Nome da biblioteca é obrigatório")
    @Size(min = 3, max = 100, message = "O nome da biblioteca deve ter entre 3 e 100 caracteres")
    private String nome;

    @NotBlank(message = "O endereço da biblioteca é obrigatório")
    @Size(min = 3, max = 100, message = "O endereço da biblioteca deve ter entre 3 e 100 caracteres")
    private String endereco;

    public BibliotecaDTO(Biblioteca entity) {
        id = entity.getId();
        nome = entity.getNome();
    }

}
