package br.com.fiap.ms_livros.service;

import br.com.fiap.ms_livros.dto.AutorDTO;
import br.com.fiap.ms_livros.dto.LivroDTO;
import br.com.fiap.ms_livros.entities.Autor;
import br.com.fiap.ms_livros.repositories.AutorRepository;
import br.com.fiap.ms_livros.service.exceptions.DatabaseException;
import br.com.fiap.ms_livros.service.exceptions.ResourceNotFoundException;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service

public class AutorService {


    @Autowired
    private AutorRepository repository;

    @Transactional(readOnly = true)
    public List<LivroDTO> findLivrosByAutor(Long autorId){
        Autor entity = repository.findById(autorId).orElseThrow(
                () -> new ResourceNotFoundException("Recurso não encontrado. ID: " + autorId)
        );

        return entity.getLivros().stream().map(LivroDTO::new).toList();
    }

    @Transactional(readOnly = true)
    public List<AutorDTO> findAll() {
        return repository.findAll()
                .stream().map(AutorDTO::new).toList();
    }


    @Transactional(readOnly = true)
    public AutorDTO findById(Long id) {
        Autor entity = repository.findById(id).orElseThrow(
                () -> new ResourceNotFoundException("Recurso não encontrado. ID: " + id)
        );
        return new AutorDTO(entity);
    }



    @Transactional
    public AutorDTO create(AutorDTO dto) {
        Autor entity = new Autor();
        copyDtoToEntity(dto, entity);
        entity = repository.save(entity);
        return new AutorDTO(entity);
    }


    @Transactional
    public AutorDTO update(Long id, AutorDTO dto){
        try{
            Autor entity = repository.getReferenceById(id);
            copyDtoToEntity(dto, entity);
            entity = repository.save(entity);
            return new AutorDTO(entity);
        } catch (EntityNotFoundException ex){
            throw new ResourceNotFoundException("Recurso não encontrado. ID: " + id);
        }
    }

    @Transactional(propagation = Propagation.SUPPORTS)
    public void delete(Long id){
        if(!repository.existsById(id)){
            throw new ResourceNotFoundException("Recurso não encontrado. ID: " + id);
        }
        try {
            repository.deleteById(id);
        } catch (DataIntegrityViolationException e) {
            throw new DatabaseException("Não é possível deletar o autor. " +
                    "Ela está sendo referenciado por um ou mais livro.");
        }
    }
    private void copyDtoToEntity(AutorDTO dto, Autor entity) {
        entity.setNome(dto.getNome());
    }


}
