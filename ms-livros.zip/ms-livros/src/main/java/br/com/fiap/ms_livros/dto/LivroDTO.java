package br.com.fiap.ms_livros.dto;

import br.com.fiap.ms_livros.entities.Livro;
import lombok.*;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@EqualsAndHashCode(of = "id")
public class LivroDTO {


    private Long id;
    private String titulo;
    private String genero;
    private Integer anoPublicacao;
    private AutorDTO autor;
    private List<BibliotecaDTO> bibliotecas;


    public LivroDTO(Livro entity) {
        this.id = entity.getId();
        this.titulo = entity.getTitulo();
        this.genero = entity.getGenero();
        this.anoPublicacao = entity.getAnoPublicacao();

        if (entity.getAutor() != null) {
            this.autor = new AutorDTO(entity.getAutor());
        }

        if (entity.getBibliotecas() != null) {
            this.bibliotecas = entity.getBibliotecas()
                    .stream()
                    .map(BibliotecaDTO::new)
                    .toList();
        }
    }



}
