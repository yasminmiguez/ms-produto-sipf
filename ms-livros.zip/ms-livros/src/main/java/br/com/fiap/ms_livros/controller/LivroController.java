    package br.com.fiap.ms_livros.controller;

    import br.com.fiap.ms_livros.dto.LivroDTO;
    import br.com.fiap.ms_livros.service.LivroService;
    import jakarta.validation.Valid;
    import org.springframework.beans.factory.annotation.Autowired;
    import org.springframework.http.ResponseEntity;
    import org.springframework.web.bind.annotation.*;
    import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

    import java.net.URI;
    import java.util.List;

    @RestController
    @RequestMapping("/livros")
    public class LivroController {

        @Autowired
        private LivroService service;

        @GetMapping
        public ResponseEntity<List<LivroDTO>> findAll() {

            List<LivroDTO> dto = service.findAll();
            return ResponseEntity.ok(dto);
        }

        @GetMapping("/{id}")
        public ResponseEntity<LivroDTO> findById(@PathVariable Long id) {

            LivroDTO dto = service.findById(id);
            return ResponseEntity.ok(dto);
        }

        @GetMapping("/teste")
        public String teste() {
            return "Controller OK!";
        }

        @PostMapping
        public ResponseEntity<LivroDTO> insert(@Valid @RequestBody LivroDTO dto) {

            dto = service.insert(dto);
            URI uri = ServletUriComponentsBuilder
                    .fromCurrentRequestUri()
                    .path("/{id}")
                    .buildAndExpand(dto.getId())
                    .toUri();
            return ResponseEntity.created(uri).body(dto);
        }

        @PutMapping("/{id}")
        public ResponseEntity<LivroDTO> update(@PathVariable Long id,
                                                 @Valid @RequestBody LivroDTO dto) {

            dto = service.update(id, dto);
            return ResponseEntity.ok(dto);
        }

        @DeleteMapping("/{id}")
        public ResponseEntity<Void> delete(@PathVariable Long id) {

            service.delete(id);
            return ResponseEntity.noContent().build();
        }

    }
