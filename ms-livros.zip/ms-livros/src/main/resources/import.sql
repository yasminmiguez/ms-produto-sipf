-- AUTO-INCREMENT: dependendo do banco, IDENTITY ou SERIAL pode variar
-- H2 aceita IDENTITY

-- ===============================
-- AUTORES
-- ===============================
INSERT INTO tb_autor (id, nome) VALUES (1, 'George Orwell');
INSERT INTO tb_autor (id, nome) VALUES (2, 'J.K. Rowling');
INSERT INTO tb_autor (id, nome) VALUES (3, 'J.R.R. Tolkien');

-- ===============================
-- BIBLIOTECAS
-- ===============================
INSERT INTO tb_biblioteca (id, nome, endereco) VALUES (1, 'Biblioteca Central', 'Rua A, 100');
INSERT INTO tb_biblioteca (id, nome, endereco) VALUES (2, 'Biblioteca Bairro', 'Rua B, 200');
INSERT INTO tb_biblioteca (id, nome, endereco) VALUES (3, 'Biblioteca Universitária', 'Av. Universitária, 500');

-- ===============================
-- LIVROS
-- ===============================
INSERT INTO tb_livro (id, titulo, genero, ano_publicacao, autor_id) VALUES (1, '1984', 'Distopia', 1949, 1);
INSERT INTO tb_livro (id, titulo, genero, ano_publicacao, autor_id) VALUES (2, 'Harry Potter e a Pedra Filosofal', 'Fantasia', 1997, 2);
INSERT INTO tb_livro (id, titulo, genero, ano_publicacao, autor_id) VALUES (3, 'O Senhor dos Anéis', 'Fantasia', 1954, 3);

-- ===============================
-- RELACIONAMENTO LIVRO <-> BIBLIOTECA (N:N)
-- ===============================
INSERT INTO tb_livro_biblioteca (livro_id, biblioteca_id) VALUES (1, 1);
INSERT INTO tb_livro_biblioteca (livro_id, biblioteca_id) VALUES (1, 2);
INSERT INTO tb_livro_biblioteca (livro_id, biblioteca_id) VALUES (2, 2);
INSERT INTO tb_livro_biblioteca (livro_id, biblioteca_id) VALUES (2, 3);
INSERT INTO tb_livro_biblioteca (livro_id, biblioteca_id) VALUES (3, 1);
INSERT INTO tb_livro_biblioteca (livro_id, biblioteca_id) VALUES (3, 3);
