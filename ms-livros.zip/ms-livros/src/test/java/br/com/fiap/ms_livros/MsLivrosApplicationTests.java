package br.com.fiap.ms_livros;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsLivrosApplicationTests {

	@Test
	void contextLoads() {
	}

}
